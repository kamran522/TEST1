# KAMI-MD-TEST2
Owner: Kamran Hasil. Authorized numbers: +923111008402, +923395267262.

Requires Node.js >= 22. Run `npm install` then `npm start` from the same server terminal.
Scan the QR shown in that terminal using WhatsApp → Linked devices → Link a device.
Session files are stored only in `./Session/` and ignored by Git. Do not commit credentials.
`SESSION` IDs and external session retrieval are disabled. Optional AI and media commands may
contact third-party services when explicitly invoked; do not send private content through them.
`REPORT_JID` optionally enables a report command that sends data to the configured JID.
No external trial/hosting checks or automatic newsletter subscriptions are performed.
Auto-update commands that fetch code from third-party GitHub accounts were disabled.
The original Baileys dependency is a third-party GitHub fork; audit or replace it before
using the bot with sensitive communications. No live WhatsApp login test was performed.
