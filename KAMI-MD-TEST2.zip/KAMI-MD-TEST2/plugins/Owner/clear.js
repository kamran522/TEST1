import ownerMiddleware from '../../utils/botUtil/Ownermiddleware.js';
import { sendInteractive } from '../../lib/sendInteractive.js';

export default async (context) => {
    await ownerMiddleware(context, async () => {
        const { client, m, store, args } = context;
        await client.sendMessage(m.chat, { react: { text: '⌛', key: m.reactKey } });

        if (!m?.chat) return;

        if (m.chat.endsWith('@broadcast') || m.chat.endsWith('@newsletter')) {
            await client.sendMessage(m.chat, { react: { text: '❌', key: m.reactKey } }).catch(() => {});
            return sendInteractive(client, m, `╭─❏ 「 CLEAR 」
│ Cannot clear this type of chat.
╰───────────────
> ©Kamran Hasil`);
        }

        try {
            let lastMessages;
            if (store?.chats?.[m.chat] && Array.isArray(store.chats[m.chat]) && store.chats[m.chat].length) {
                lastMessages = store.chats[m.chat].slice(-1);
            }

            const keepStarred = Array.isArray(args) && args.some((a) => String(a).toLowerCase() === 'keepstarred');
            if (typeof client.clearChat === 'function') {
                await client.clearChat(m.chat, lastMessages, keepStarred ? { deleteStarred: false } : undefined);
            } else {
                await client.chatModify({ clear: true, lastMessages, deleteStarred: keepStarred ? false : undefined }, m.chat);
            }
            await client.sendMessage(m.chat, { react: { text: '✅', key: m.reactKey } }).catch(() => {});
            await sendInteractive(client, m, `╭─❏ 「 CLEARED 」
│ Chat cleared.
╰───────────────
> ©Kamran Hasil`);
        } catch (err) {
            await client.sendMessage(m.chat, { react: { text: '❌', key: m.reactKey } }).catch(() => {});
            const msg = String(err?.message || err || '');
            if (msg.includes('myAppStateKey') || msg.includes('App state not ready') || msg.includes('app-state') || err?.output?.statusCode === 404) {
                return sendInteractive(client, m, `╭─❏ 「 NOT READY 」
│ App state still syncing after connect.
│ Wait a few seconds then try again.
╰───────────────
> ©Kamran Hasil`);
            }
            await sendInteractive(client, m, `╭─❏ 「 ERROR 」
│ Failed to clear chat.
╰───────────────
> ©Kamran Hasil`);
        }
    });
};
