// Local, transparent configuration. Keep API keys only in environment variables.
export const TOXIC_API_KEY = process.env.TOXIC_API_KEY || '';
export const TOXIC_API_FALLBACK = process.env.TOXIC_API_FALLBACK || '';
export const GROQ_API_KEY = process.env.GROQ_API_KEY || '';
export const GROQ_API_KEYS = (process.env.GROQ_API_KEYS || '').split(',').filter(Boolean);
export const GITHUB_TOKEN = process.env.GITHUB_TOKEN || '';
export const GEMINI_API_KEY = process.env.GEMINI_API_KEY || '';
