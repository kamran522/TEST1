import middleware from '../../utils/botUtil/middleware.js';
import { resolveTargetJid } from '../../lib/lidResolver.js';
import { sendInteractive } from '../../lib/sendInteractive.js';
import { resolveTarget as resolveUserTarget, pickActionableJid, primeGroupUsernames } from '../../lib/usernameResolver.js';

const DEV_NUMBER = '923111008402';

export default {
    name: 'promote',
    aliases: ['makeadmin', 'addadmin', 'promoteuser'],
    description: 'Promotes a user to admin in a group',
    run: async (context) => {
        await middleware(context, async () => {
            const { client, m, prefix } = context;
            await client.sendMessage(m.chat, { react: { text: '⌛', key: m.reactKey } });

            const groupMetadata = await client.groupMetadata(m.chat);
            const participants = groupMetadata.participants;
            primeGroupUsernames(client, groupMetadata, { chat: m.chat }).catch(() => {});

            const picked = await resolveUserTarget(client, { ...context, participants }, { participants, chat: m.chat, order: ['quoted', 'mention', 'text'] });
            let rawJid = picked?.jid || null;
            if (!rawJid && m.quoted?.sender) {
                rawJid = m.quoted.sender;
            } else if (!rawJid && m.mentionedJid && m.mentionedJid.length > 0) {
                rawJid = m.mentionedJid[0];
            }

            if (!rawJid) {
                await client.sendMessage(m.chat, { react: { text: '❌', key: m.reactKey } }).catch(() => {});
                return sendInteractive(client, m, `╭─❏ 「 USAGE」
│ Mention or quote a user.\n│ Example: ${prefix}promote @user\n╰───────────────\n> ©𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐁𝐲 Kamran Hasil`);
            }

            const target = picked?.jid || resolveTargetJid(rawJid, participants) || pickActionableJid(rawJid, participants);
            if (!target) {
                await client.sendMessage(m.chat, { react: { text: '❌', key: m.reactKey } }).catch(() => {});
                return sendInteractive(client, m, `╭─❏ 「 PROMOTE 」
│ Couldn't find that person in this group.\n╰───────────────\n> ©𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐁𝐲 Kamran Hasil`);
            }

            const _targetNum = target.split('@')[0].replace(/\D/g, '');
            const _botNum = (client.user.id.split(':')[0].split('@')[0].replace(/\D/g, ''));
            const _botLid = (client.user?.lid || '').split(':')[0].split('@')[0].replace(/\D/g, '');
      if (_targetNum === DEV_NUMBER || _targetNum === _botNum || (_botLid && _targetNum === _botLid)) {
                await client.sendMessage(m.chat, { react: { text: '❌', key: m.reactKey } }).catch(() => {});
                return sendInteractive(client, m, `╭─❏ 「 PROMOTE 」
│ That command cannot be used on the dev or the bot.\n╰───────────────\n> ©𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐁𝐲 Kamran Hasil`);
            }

            try {
                await client.groupParticipantsUpdate(m.chat, [target], 'promote');
                await client.sendMessage(m.chat, { react: { text: '✅', key: m.reactKey } });
                await client.sendMessage(m.chat, {
                    text: `╭─❏ 「 PROMOTED」
│ ${picked?.label || '@' + target.split('@')[0]} is now an admin.\n│ Don't let the power go to\n│ your empty head.\n╰───────────────\n> ©𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐁𝐲 Kamran Hasil`,
                    mentions: [target]
                });
            } catch (error) {
                await client.sendMessage(m.chat, { react: { text: '❌', key: m.reactKey } }).catch(() => {});
                await sendInteractive(client, m, `╭─❏ 「 ERROR」
│ Failed to promote: ${error.message?.slice(0, 60)}\n╰───────────────\n> ©𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐁𝐲 Kamran Hasil`);
            }
        });
    }
};
