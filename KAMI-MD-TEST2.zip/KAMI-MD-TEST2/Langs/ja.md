# Toxic-MD — Japanese (日本語)

[⬅ Back to main README](../README.md)

**Toxic-MD** は Baileys Multi-Device 上に構築された現代的な WhatsApp ボットです。グループ管理、自動化、チャット保護、楽しい/便利なコマンドを提供します。

### What's New in v1.1.1
- 🌐 **Language System** — Change language with `.language`. 17 languages supported.
- 📊 **Auto Reports** — Daily group stats every 24 hours. Toggle with `.autoreport on/off`.
- 🖼️ **CDN Upload** — Upload media to WhatsApp CDN and get URL with `.cdnwa`.
- 💾 **CRM Store** — Persistent JSON message storage for better recovery and inspection.
- 🔧 **Improved LID Mapping** — Better handling of Linked Device identifiers.
- ⚡ **Higher Message Cache** — MESSAGE_CACHE_LIMIT set to 50000 for improved reliability.

### Key Features
| Feature | Details |
| --- | --- |
| ✅ Multi-Device Support | No constant QR scanning required |
| ⚡ Fast & Stable | Optimized for continuous uptime |
| 🚀 Easy Deployment | Works on any hosting platform |
| 🧑‍💻 Beginner Friendly | Simple setup, clear documentation |
| 🔧 Highly Customizable | Flexible prefix, modes, settings, and languages |
| 🤖 AI-Powered | Auto AI chat with Groq/Llama |
| 🛡️ Group Protection | Anti-link, anti-badword, anti-group-status, anti-delete, view-once recovery, and more |
| 🌐 Multi-Language | 17 languages supported |
| 📊 Auto Reports | Daily group activity summaries |

### Quick Start
1. Clone / download the bot
2. Install dependencies: `npm install`
3. Configure settings
4. Run: `npm start`

Full installation guides (Termux, Heroku, Railway, VPS, etc.) are in the main [README](../README.md).

Change the bot's reply language anytime with: `.language <code>` (Owner only)

---

[⬅ Back to main README](../README.md)
