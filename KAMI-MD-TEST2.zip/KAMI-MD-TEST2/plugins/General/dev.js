export default {
  name: 'dev',
  aliases: ['developer', 'contact', 'owner', 'creator', 'devcontact'],
  description: 'Show current operator contacts',
  run: async ({ client, m }) => {
    await client.sendMessage(m.chat, {
      text: 'KAMI-MD-TEST2\nOwner: Kamran Hasil\nWhatsApp: +923111008402 / +923395267262\nThese are the configured operator numbers.'
    }, { quoted: m });
  }
};
