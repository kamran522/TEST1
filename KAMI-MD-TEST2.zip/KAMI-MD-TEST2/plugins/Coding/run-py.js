import { c, cpp, node, python, java } from 'compile-run';
import { sendInteractive } from '../../lib/sendInteractive.js';
export default async (context) => {
    const { client, m } = context;
    await client.sendMessage(m.chat, { react: { text: '⌛', key: m.reactKey } });


    if (m.quoted && m.quoted.text) {
        const code = m.quoted.text;

async function runCode() {
  try {
    let result = await python.runSource(code);
    console.log(result);
    sendInteractive(client, m, `╭─❏ 「 PYTHON OUTPUT」
│ ${result.stdout || 'No output'}\n${result.stderr ? '│ stderr: ' + result.stderr + '\n' : ''}╰───────────────\n> ©𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐁𝐲 Kamran Hasil`);
  } catch (err) {
    await client.sendMessage(m.chat, { react: { text: '❌', key: m.reactKey } }).catch(() => {});
    console.log(err);
    sendInteractive(client, m, `╭─❏ 「 PYTHON ERROR」
│ ${err.stderr || err.message}\n╰───────────────\n> ©𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐁𝐲 Kamran Hasil`);
  }
}

runCode();

} else { 

sendInteractive(client, m, `╭─❏ 「 PYTHON COMPILER」
│ Quote a valid and short Python code\n│ to compile, you absolute walnut.\n╰───────────────\n> ©𝐏𝐨𝐰𝐞𝐫𝐞𝐝 𝐁𝐲 Kamran Hasil`)

}

}
